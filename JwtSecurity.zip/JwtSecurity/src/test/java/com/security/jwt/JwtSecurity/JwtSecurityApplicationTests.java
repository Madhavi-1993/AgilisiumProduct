package com.security.jwt.JwtSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
